import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { CanvasTexture, type Mesh } from "three";
import { ContactShadows } from "@react-three/drei";
import { ROOMS, ROSTER } from "@/lib/company/layout";
import type { OfficeEmployee } from "@/types/office";
import { CameraController, type FloorControl } from "./CameraController";
import { EmployeeAvatar } from "./EmployeeAvatar";
import { OfficeRoom } from "./OfficeRoom";

function StatusWall({ employees }: { employees: OfficeEmployee[] }) {
  const mesh = useRef<Mesh>(null);
  const texture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 640;
    canvas.height = 360;
    const map = new CanvasTexture(canvas);
    map.anisotropy = 4;
    return { canvas, map };
  }, []);

  useFrame(() => {
    const ctx = texture.canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#0c1218";
    ctx.fillRect(0, 0, 640, 360);
    ctx.strokeStyle = "#3ec5ff";
    ctx.globalAlpha = 0.85;
    ctx.lineWidth = 3;
    ctx.strokeRect(16, 16, 608, 328);
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#d6b36a";
    ctx.font = "600 28px Outfit, sans-serif";
    ctx.fillText("COMPANY FLOOR", 40, 62);
    ctx.font = "500 22px Outfit, sans-serif";
    employees.forEach((employee, index) => {
      const y = 112 + index * 38;
      ctx.fillStyle = employee.status === "failed" ? "#e15b64" : "#3ec5ff";
      ctx.fillRect(40, y - 14, 10, 10);
      ctx.fillStyle = "#e7eef6";
      ctx.fillText(employee.name, 64, y);
      ctx.fillStyle = "#8d9aab";
      ctx.fillText(employee.status, 280, y);
    });
    texture.map.needsUpdate = true;
    const material = mesh.current?.material;
    if (material && !Array.isArray(material) && "emissiveIntensity" in material) {
      material.emissiveIntensity = 0.45;
    }
  });

  return (
    <mesh ref={mesh} position={[0, 1.65, 3.4]}>
      <planeGeometry args={[3.5, 1.96]} />
      <meshStandardMaterial map={texture.map} emissive="#081018" emissiveIntensity={0.35} toneMapped={false} />
    </mesh>
  );
}

function MeetingTable() {
  return (
    <group position={[0, 0, -2.1]}>
      <mesh position={[0, 0.74, 0]} castShadow receiveShadow>
        <boxGeometry args={[3.3, 0.08, 1.35]} />
        <meshStandardMaterial color="#1a1814" metalness={0.5} roughness={0.32} />
      </mesh>
      <mesh position={[0, 0.785, 0]}>
        <boxGeometry args={[2.9, 0.012, 0.035]} />
        <meshStandardMaterial color="#d6b36a" emissive="#d6b36a" emissiveIntensity={0.45} toneMapped={false} />
      </mesh>
      {[-1.35, 1.35].map((x) => (
        <mesh key={x} position={[x, 0.38, 0]}>
          <boxGeometry args={[0.08, 0.7, 1.05]} />
          <meshStandardMaterial color="#12171e" />
        </mesh>
      ))}
    </group>
  );
}

export function OfficeScene({
  employees,
  selectedId,
  onSelect,
  control,
}: {
  employees: OfficeEmployee[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  control: FloorControl;
}) {
  const alexander = employees.find((employee) => employee.id === "alexander");
  const accents = Object.fromEntries(ROSTER.map((person) => [person.id, person.accent]));
  const busyRooms = new Set(
    employees
      .filter((employee) => ["working", "review", "failed", "assigned"].includes(employee.status))
      .map((employee) => employee.room_id),
  );

  return (
    <>
      <color attach="background" args={["#07090e"]} />
      <fog attach="fog" args={["#07090e", 18, 48]} />
      <ambientLight intensity={0.38} />
      <directionalLight
        position={[10, 18, 8]}
        intensity={1.2}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={64}
        shadow-camera-left={-26}
        shadow-camera-right={26}
        shadow-camera-top={26}
        shadow-camera-bottom={-26}
        shadow-bias={-0.0004}
      />
      <pointLight position={[0, 3.2, -16]} intensity={6} color="#d6b36a" distance={12} />
      <pointLight position={[0, 3.1, -2]} intensity={5} color="#3ec5ff" distance={14} />
      <pointLight position={[13, 2.8, 8]} intensity={4} color="#3ec5ff" distance={10} />
      <pointLight position={[-13, 2.8, 8]} intensity={3.2} color="#d6b36a" distance={10} />

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[46, 48]} />
        <meshStandardMaterial color="#0c1016" roughness={0.92} metalness={0.08} />
      </mesh>
      <gridHelper args={[40, 40, "#1d3c52", "#16202b"]} position={[0, 0.012, 0]} />
      <ContactShadows position={[0, 0.03, 0]} opacity={0.4} scale={36} blur={2.4} far={8} color="#020304" />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 2.2]}>
        <ringGeometry args={[5.4, 5.48, 72]} />
        <meshBasicMaterial color="#d6b36a" transparent opacity={0.4} />
      </mesh>

      {ROOMS.map((room) => (
        <OfficeRoom
          key={room.id}
          room={room}
          deskActive={room.id === "meeting" ? employees.some((employee) => employee.status === "meeting") : busyRooms.has(room.id)}
        />
      ))}
      <MeetingTable />
      <StatusWall employees={employees} />

      {employees.map((employee) => (
        <EmployeeAvatar
          key={employee.id}
          name={employee.name}
          role={employee.role}
          status={employee.status}
          accent={accents[employee.id] ?? "#3ec5ff"}
          animation={employee.animation}
          position={employee.position}
          facing={employee.facing}
          selected={selectedId === employee.id}
          onSelect={() => onSelect(employee.id)}
        />
      ))}

      <CameraController
        control={control}
        alexander={alexander ? { x: alexander.position.x, z: alexander.position.z } : null}
      />
    </>
  );
}
