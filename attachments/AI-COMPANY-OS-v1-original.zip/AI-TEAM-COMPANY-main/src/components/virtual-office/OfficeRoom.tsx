import { useEffect, useMemo } from "react";
import { CanvasTexture } from "three";
import type { Aabb, OfficeRoom as Room } from "@/types/office";
import { ACCENT, wallsFor } from "@/lib/company/layout";
import { Desk } from "./Desk";

function Wall({ box, accent }: { box: Aabb; accent: string }) {
  const sx = Math.max(0.08, box.maxX - box.minX);
  const sz = Math.max(0.08, box.maxZ - box.minZ);
  const cx = (box.minX + box.maxX) / 2;
  const cz = (box.minZ + box.maxZ) / 2;
  return (
    <group position={[cx, 0, cz]}>
      <mesh position={[0, 0.38, 0]} castShadow receiveShadow>
        <boxGeometry args={[sx, 0.76, sz]} />
        <meshStandardMaterial color="#141a22" metalness={0.22} roughness={0.62} />
      </mesh>
      <mesh position={[0, 1.72, 0]}>
        <boxGeometry args={[sx, 1.86, sz]} />
        <meshStandardMaterial
          color="#c5deea"
          transparent
          opacity={0.14}
          roughness={0.04}
          metalness={0.2}
          depthWrite={false}
        />
      </mesh>
      <mesh position={[0, 2.68, 0]}>
        <boxGeometry args={[sx, 0.045, sz]} />
        <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={0.85} toneMapped={false} />
      </mesh>
    </group>
  );
}

export function OfficeRoom({ room, deskActive }: { room: Room; deskActive: boolean }) {
  const accent = room.accent === "gold" ? ACCENT.gold : ACCENT.blue;
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[room.x, 0.02, room.z]} receiveShadow>
        <planeGeometry args={[room.w - 0.2, room.d - 0.2]} />
        <meshStandardMaterial color={room.accent === "gold" ? "#16140f" : "#10161c"} roughness={0.85} />
      </mesh>
      {wallsFor(room).map((box, index) => (
        <Wall key={`${room.id}-${index}`} box={box} accent={accent} />
      ))}
      {room.id !== "meeting" && <Desk room={room} active={deskActive} />}
      <RoomLabel name={room.name} gold={room.accent === "gold"} position={[room.x, 2.45, room.z]} />
    </group>
  );
}

function RoomLabel({ name, gold, position }: { name: string; gold: boolean; position: [number, number, number] }) {
  const texture = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 96;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.clearRect(0, 0, 512, 96);
      ctx.fillStyle = "rgba(7, 9, 14, 0.55)";
      ctx.fillRect(24, 16, 464, 64);
      ctx.fillStyle = gold ? "#d6b36a" : "#e7eef6";
      ctx.font = "600 34px Outfit, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(name.toUpperCase(), 256, 58);
    }
    const map = new CanvasTexture(canvas);
    map.needsUpdate = true;
    return map;
  }, [gold, name]);
  useEffect(() => () => texture.dispose(), [texture]);
  return (
    <sprite position={position} scale={[2.4, 0.45, 1]}>
      <spriteMaterial map={texture} transparent depthWrite={false} />
    </sprite>
  );
}
