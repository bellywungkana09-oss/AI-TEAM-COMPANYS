import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import type { Group } from "three";
import type { OfficeAnimation } from "@/types/office";
import type { EmployeeStatus } from "@/types/company";
import { EmployeeStatusBubble } from "./EmployeeStatusBubble";

type Props = {
  name: string;
  role: string;
  status: EmployeeStatus;
  accent: string;
  animation: OfficeAnimation;
  position: { x: number; y: number; z: number };
  facing: number;
  selected: boolean;
  onSelect: () => void;
};

export function EmployeeAvatar({
  name,
  role,
  status,
  accent,
  animation,
  position,
  facing,
  selected,
  onSelect,
}: Props) {
  const root = useRef<Group>(null);
  const leftArm = useRef<Group>(null);
  const rightArm = useRef<Group>(null);
  const leftLeg = useRef<Group>(null);
  const rightLeg = useRef<Group>(null);
  const head = useRef<Group>(null);
  const spot = useRef({ x: position.x, z: position.z, facing });

  useFrame((state, delta) => {
    const rig = root.current;
    if (!rig) return;
    const dt = Math.min(delta, 0.1);
    const current = spot.current;
    current.x += (position.x - current.x) * Math.min(1, dt * 2.4);
    current.z += (position.z - current.z) * Math.min(1, dt * 2.4);
    let turn = Math.atan2(Math.sin(facing - current.facing), Math.cos(facing - current.facing));
    current.facing += turn * Math.min(1, dt * 4);
    const remain = Math.hypot(position.x - current.x, position.z - current.z);
    const anim: OfficeAnimation = remain > 0.22 ? "walk" : animation;
    const t = state.clock.elapsedTime;
    const seated = anim === "working" || anim === "review";
    rig.position.set(current.x, seated ? -0.22 : Math.sin(t * 1.6) * 0.015, current.z);
    rig.rotation.y = Math.PI + current.facing;

    const armL = leftArm.current;
    const armR = rightArm.current;
    const legL = leftLeg.current;
    const legR = rightLeg.current;
    const skull = head.current;
    if (!armL || !armR || !legL || !legR || !skull) return;

    armL.rotation.set(0.12, 0, 0.08);
    armR.rotation.set(0.12, 0, -0.08);
    legL.rotation.set(0, 0, 0);
    legR.rotation.set(0, 0, 0);
    skull.rotation.set(0, Math.sin(t * 0.6) * 0.12, 0);

    if (anim === "walk") {
      const step = Math.sin(t * 8);
      legL.rotation.x = step * 0.55;
      legR.rotation.x = -step * 0.55;
      armL.rotation.x = -step * 0.45;
      armR.rotation.x = step * 0.45;
    } else if (anim === "working") {
      armL.rotation.x = -0.95 + Math.sin(t * 11) * 0.22;
      armR.rotation.x = -0.95 + Math.sin(t * 11 + 1.2) * 0.22;
      skull.rotation.x = 0.28;
    } else if (anim === "review") {
      armL.rotation.x = -0.7;
      armR.rotation.x = -0.75;
      skull.rotation.x = 0.42;
    } else if (anim === "meeting") {
      armR.rotation.x = -0.7 + Math.sin(t * 2.2) * 0.35;
      armR.rotation.z = -0.25;
      skull.rotation.y = Math.sin(t * 1.1) * 0.3;
    } else if (anim === "thinking") {
      armR.rotation.x = -1.35;
      armR.rotation.z = -0.45;
      skull.rotation.x = -0.12 + Math.sin(t * 0.8) * 0.06;
    } else if (anim === "failed") {
      rig.position.x += Math.sin(t * 16) * 0.012;
      skull.rotation.x = 0.15;
    } else if (anim === "completed") {
      skull.rotation.x = Math.max(0, Math.sin(t * 1.4)) * 0.28;
    }
  });

  return (
    <group ref={root} onClick={(event) => { event.stopPropagation(); onSelect(); }}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]}>
        <ringGeometry args={[0.28, selected ? 0.4 : 0.34, 28]} />
        <meshBasicMaterial color={status === "failed" ? "#e15b64" : accent} transparent opacity={selected ? 0.95 : 0.55} />
      </mesh>
      <group ref={leftLeg} position={[-0.1, 0.74, 0]}>
        <mesh position={[0, -0.28, 0]} castShadow>
          <capsuleGeometry args={[0.065, 0.34, 4, 8]} />
          <meshStandardMaterial color="#1b2028" roughness={0.7} />
        </mesh>
      </group>
      <group ref={rightLeg} position={[0.1, 0.74, 0]}>
        <mesh position={[0, -0.28, 0]} castShadow>
          <capsuleGeometry args={[0.065, 0.34, 4, 8]} />
          <meshStandardMaterial color="#1b2028" roughness={0.7} />
        </mesh>
      </group>
      <mesh position={[0, 1.02, 0]} castShadow>
        <boxGeometry args={[0.4, 0.46, 0.22]} />
        <meshStandardMaterial color="#2a3140" metalness={0.28} roughness={0.46} />
      </mesh>
      <mesh position={[0, 1.16, 0.1]}>
        <boxGeometry args={[0.14, 0.05, 0.02]} />
        <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={0.55} />
      </mesh>
      <group ref={leftArm} position={[-0.26, 1.2, 0]}>
        <mesh position={[0, -0.2, 0]} castShadow>
          <capsuleGeometry args={[0.045, 0.26, 4, 8]} />
          <meshStandardMaterial color="#343c4c" roughness={0.5} />
        </mesh>
      </group>
      <group ref={rightArm} position={[0.26, 1.2, 0]}>
        <mesh position={[0, -0.2, 0]} castShadow>
          <capsuleGeometry args={[0.045, 0.26, 4, 8]} />
          <meshStandardMaterial color="#343c4c" roughness={0.5} />
        </mesh>
      </group>
      <group ref={head} position={[0, 1.46, 0]}>
        <mesh castShadow>
          <sphereGeometry args={[0.125, 22, 16]} />
          <meshStandardMaterial color="#e4d0be" roughness={0.62} />
        </mesh>
        <mesh position={[0, 0.05, -0.01]}>
          <sphereGeometry args={[0.128, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.48]} />
          <meshStandardMaterial color="#17191e" roughness={0.55} />
        </mesh>
      </group>
      {(animation === "review" || status === "review") && (
        <mesh position={[0.02, 1.02, 0.2]} rotation={[-0.55, 0, 0]}>
          <boxGeometry args={[0.2, 0.13, 0.018]} />
          <meshStandardMaterial color="#0e141b" emissive="#3ec5ff" emissiveIntensity={0.45} />
        </mesh>
      )}
      <EmployeeStatusBubble name={name} role={role} status={status} />
    </group>
  );
}
