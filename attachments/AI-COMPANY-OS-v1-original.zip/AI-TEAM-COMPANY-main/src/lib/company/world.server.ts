import {
  FOUNDER_ID,
  commandWorld,
  companyStatus,
  createWorld,
  eventsSince,
  officeState,
  snapshotEmployees,
  tickWorld,
  type World,
} from "./world.ts";
import type { CompanyEvent } from "@/types/company";

type Listener = (events: CompanyEvent[]) => void;

type Store = {
  world: World;
  listeners: Set<Listener>;
  timer?: ReturnType<typeof setInterval>;
};

const globalRef = globalThis as typeof globalThis & { __companyStore?: Store };

function store(): Store {
  if (!globalRef.__companyStore) {
    globalRef.__companyStore = { world: createWorld(Date.now()), listeners: new Set() };
  }
  return globalRef.__companyStore;
}

function emit(events: CompanyEvent[]) {
  if (events.length === 0) return;
  for (const listener of store().listeners) listener(events);
}

export function ensureCompanyClock(): void {
  const current = store();
  if (current.timer) return;
  current.timer = setInterval(() => {
    emit(tickWorld(current.world, Date.now()));
  }, 1000);
}

export function readEmployees() {
  ensureCompanyClock();
  const now = Date.now();
  tickWorld(store().world, now);
  return snapshotEmployees(store().world, now);
}

export function readStatus() {
  ensureCompanyClock();
  const now = Date.now();
  tickWorld(store().world, now);
  return companyStatus(store().world, now);
}

export function readProjects() {
  ensureCompanyClock();
  return store().world.projects;
}

export function readTasks() {
  ensureCompanyClock();
  return store().world.tasks;
}

export function readActivity() {
  ensureCompanyClock();
  return store().world.activity;
}

export function readOfficeState() {
  ensureCompanyClock();
  const now = Date.now();
  tickWorld(store().world, now);
  return officeState(store().world, now);
}

export function readEvents(since: number) {
  ensureCompanyClock();
  const now = Date.now();
  emit(tickWorld(store().world, now));
  return eventsSince(store().world, since);
}

export function submitCommand(command: string, founderId: string | null) {
  if (!founderId) {
    return { status: 401, body: { error: { code: "unauthorized", message: "X-Founder-ID required" } } };
  }
  ensureCompanyClock();
  const now = Date.now();
  const result = commandWorld(store().world, command, now);
  emit(eventsSince(store().world, store().world.seq - 12));
  return { status: 201, body: result, founderId: founderId || FOUNDER_ID };
}

export function subscribeCompanyEvents(listener: Listener): () => void {
  ensureCompanyClock();
  const current = store();
  current.listeners.add(listener);
  return () => current.listeners.delete(listener);
}

export function helloEvent(): CompanyEvent {
  return {
    id: "hello",
    seq: 0,
    type: "company_status_changed",
    occurred_at: new Date().toISOString(),
    data: { connection: "established" },
  };
}

export function __resetCompanyWorldForTests(now = Date.now()): World {
  const fresh = createWorld(now);
  globalRef.__companyStore = { world: fresh, listeners: new Set() };
  return fresh;
}
