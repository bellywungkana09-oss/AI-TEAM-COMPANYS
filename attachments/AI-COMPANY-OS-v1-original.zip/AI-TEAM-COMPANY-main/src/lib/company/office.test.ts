import assert from "node:assert/strict";
import { test } from "node:test";
import { animationFor, poseFor, ROOMS } from "./layout.ts";
import { stepWalker } from "./walker.ts";
import { commandWorld, createWorld, officeState, tickWorld } from "./world.ts";

test("virtual office state includes rooms and employee positions", () => {
  const world = createWorld(1_700_000_000_000);
  const state = officeState(world, world.epoch);
  assert.ok(state.office.rooms.length >= 7);
  assert.equal(state.employees.length, 6);
  const alexander = state.employees.find((employee) => employee.name === "Alexander");
  const emma = state.employees.find((employee) => employee.name === "Emma");
  assert.ok(alexander);
  assert.equal(alexander.status, "idle");
  assert.equal(alexander.animation, "thinking");
  assert.ok(alexander.position.z < -10);
  assert.equal(emma?.status, "review");
  assert.equal(emma?.animation, "review");
  assert.ok((emma?.position.z ?? 0) > 10);
  assert.ok(ROOMS.some((room) => room.id === "meeting"));
});

test("status changes retarget avatars and emit company events", () => {
  const world = createWorld(0);
  const emitted = tickWorld(world, 12_000);
  const state = officeState(world, 12_000);
  const meeting = state.employees.filter((employee) => employee.status === "meeting");
  assert.ok(meeting.length >= 2);
  for (const employee of meeting) {
    assert.equal(employee.animation, "meeting");
    assert.ok(Math.abs(employee.position.z + 2.1) < 3);
  }
  assert.ok(emitted.some((event) => event.type === "employee_status_changed"));
  assert.ok(emitted.some((event) => event.type === "meeting_started"));
});

test("founder command assigns work without inventing employees", () => {
  const world = createWorld(0);
  const result = commandWorld(world, "Buat website coffee shop", 5_000);
  assert.equal(result.project, "Website Coffee Shop");
  assert.equal(result.status, "planning");
  const state = officeState(world, 5_000);
  assert.equal(state.employees.length, 6);
  const alexander = state.employees.find((employee) => employee.id === "alexander");
  assert.equal(alexander?.status, "working");
  assert.match(alexander?.current_task ?? "", /coffee shop/i);
  const david = state.employees.find((employee) => employee.id === "david");
  assert.equal(david?.status, "assigned");
  assert.equal(animationFor("David", "assigned", false), "walk");
});

test("A turns left and D turns right while moving forward", () => {
  let left = { x: 0, z: 6.6, yaw: 0, speed: 0 };
  const keysA = new Set(["KeyW", "KeyA"]);
  for (let i = 0; i < 40; i += 1) left = stepWalker(left, keysA, { steer: 0, throttle: 0 }, null, 0.016);
  assert.ok(left.speed > 0.1, `expected speed, got ${left.speed}`);
  assert.ok(left.yaw > 0.05, `A should increase yaw, got ${left.yaw}`);

  let right = { x: 0, z: 6.6, yaw: 0, speed: 0 };
  const keysD = new Set(["KeyW", "KeyD"]);
  for (let i = 0; i < 40; i += 1) right = stepWalker(right, keysD, { steer: 0, throttle: 0 }, null, 0.016);
  assert.ok(right.yaw < -0.05, `D should decrease yaw, got ${right.yaw}`);
});

test("desk pose differs from the meeting pose", () => {
  const desk = poseFor("david", "working");
  const meet = poseFor("david", "meeting");
  assert.ok(Math.hypot(desk.position.x - meet.position.x, desk.position.z - meet.position.z) > 4);
});
