import type {
  Activity,
  CompanyEvent,
  CompanyStatus,
  Employee,
  EmployeeStatus,
  FounderCommandResult,
  Project,
  Task,
} from "@/types/company";
import type { OfficeEmployee, VirtualOfficeState } from "@/types/office";
import { ROOMS, ROSTER, animationFor, poseFor } from "./layout.ts";

export const PHASE_MS = 12_000;
export const FOUNDER_ID = "00000000-0000-4000-8000-000000000001";

type Beat = { status: EmployeeStatus; task: string };

const SCRIPTS: Record<string, Beat[]> = {
  alexander: [
    { status: "idle", task: "Available for founder direction" },
    { status: "meeting", task: "Hosting the floor sync" },
    { status: "working", task: "Drafting company priorities" },
    { status: "review", task: "Reading the morning brief" },
  ],
  marcus: [
    { status: "working", task: "Reviewing service boundaries" },
    { status: "meeting", task: "Architecture sync" },
    { status: "review", task: "Reading the technical plan" },
    { status: "working", task: "Updating the system map" },
  ],
  olivia: [
    { status: "working", task: "Writing product requirements" },
    { status: "meeting", task: "Scoping the next slice" },
    { status: "working", task: "Ordering the user stories" },
    { status: "review", task: "Checking the requirement draft" },
  ],
  sophia: [
    { status: "working", task: "Composing the design system" },
    { status: "meeting", task: "Design critique" },
    { status: "working", task: "Refining the interface frames" },
    { status: "idle", task: "Waiting on the next brief" },
  ],
  david: [
    { status: "working", task: "Implementing the delivery surface" },
    { status: "meeting", task: "Implementation sync" },
    { status: "working", task: "Wiring the company monitors" },
    { status: "assigned", task: "Picking up the next engineering task" },
  ],
  emma: [
    { status: "review", task: "Reviewing quality gates" },
    { status: "meeting", task: "QA sync" },
    { status: "failed", task: "Regression on the delivery gate" },
    { status: "working", task: "Re-running the quality checklist" },
  ],
};

const PROJECT_PHASE = ["development", "testing", "development", "planning"] as const;

type Override = { status: EmployeeStatus; task: string; until: number; then?: Beat & { until: number } };

export type World = {
  epoch: number;
  seq: number;
  applied: Record<string, EmployeeStatus>;
  overrides: Record<string, Override | undefined>;
  meetingKey: string;
  projects: Project[];
  tasks: Task[];
  activity: Activity[];
  events: CompanyEvent[];
  phase: number;
};

function uid(prefix: string): string {
  return `${prefix}-${crypto.randomUUID()}`;
}

function stamp(now: number): string {
  return new Date(now).toISOString();
}

function pushEvent(world: World, now: number, type: CompanyEvent["type"], data: Record<string, unknown>): CompanyEvent {
  world.seq += 1;
  const event: CompanyEvent = {
    id: uid("evt"),
    seq: world.seq,
    type,
    occurred_at: stamp(now),
    data,
  };
  world.events.push(event);
  if (world.events.length > 80) world.events.splice(0, world.events.length - 80);
  return event;
}

function log(world: World, now: number, event: string, description: string) {
  world.activity.unshift({ id: uid("act"), event, description, timestamp: stamp(now) });
  if (world.activity.length > 40) world.activity.pop();
}

export function createWorld(now: number): World {
  const world: World = {
    epoch: now,
    seq: 0,
    applied: {},
    overrides: {},
    meetingKey: "",
    projects: [
      {
        id: "proj-command-surface",
        name: "Founder Command Surface",
        status: "development",
        progress: 46,
        created_at: stamp(now),
      },
    ],
    tasks: [],
    activity: [],
    events: [],
    phase: 0,
  };
  const titles: Record<string, string> = {
    alexander: "Company priorities",
    marcus: "Technical plan",
    olivia: "Requirements",
    sophia: "Design frames",
    david: "Delivery surface",
    emma: "Quality gates",
  };
  for (const person of ROSTER) {
    const beat = beatFor(world, person.id, now);
    world.applied[person.id] = beat.status;
    world.tasks.push({
      id: `task-${person.id}`,
      title: titles[person.id] ?? person.name,
      status: beat.status === "review" ? "review" : beat.status === "completed" ? "done" : "in_progress",
      priority: person.id === "alexander" ? "high" : "medium",
      progress: person.id === "emma" ? 62 : 40,
      assigned_employee: person.name,
      project_id: world.projects[0]!.id,
    });
  }
  log(world, now, "company_online", "Company floor is live. Alexander is in the CEO room.");
  return world;
}

function phaseIndex(world: World, now: number): number {
  const elapsed = Math.max(0, now - world.epoch);
  return Math.floor(elapsed / PHASE_MS) % SCRIPTS.alexander!.length;
}

function beatFor(world: World, id: string, now: number): Beat {
  const override = world.overrides[id];
  if (override && override.until > now) return override;
  if (override?.then && override.until <= now && override.then.until > now) return override.then;
  return SCRIPTS[id]![phaseIndex(world, now)]!;
}

export function snapshotEmployees(world: World, now: number): Employee[] {
  return ROSTER.map((person) => {
    const beat = beatFor(world, person.id, now);
    return {
      id: person.id,
      name: person.name,
      role: person.role,
      department: person.department,
      status: beat.status,
      current_task: beat.task,
      skills: person.skills,
    };
  });
}

export function officeState(world: World, now: number): VirtualOfficeState {
  const employees: OfficeEmployee[] = snapshotEmployees(world, now).map((employee) => {
    const pose = poseFor(employee.id, employee.status);
    return {
      ...employee,
      room_id: ROSTER.find((person) => person.id === employee.id)?.room_id ?? "meeting",
      position: pose.position,
      facing: pose.facing,
      animation: animationFor(employee.name, employee.status, employee.status === "assigned"),
    };
  });
  return { office: { rooms: ROOMS }, employees };
}

export function companyStatus(world: World, now: number): CompanyStatus {
  const employees = snapshotEmployees(world, now);
  const activeTasks = employees.filter((employee) =>
    ["assigned", "working", "review", "meeting"].includes(employee.status),
  ).length;
  return {
    employees_total: employees.length,
    projects_total: world.projects.length,
    active_projects: world.projects.filter((project) => project.status !== "completed").length,
    active_tasks: activeTasks,
    activities_today: world.activity.length,
    system_status: "online",
  };
}

export function tickWorld(world: World, now: number): CompanyEvent[] {
  const before = world.events.length;
  const phase = phaseIndex(world, now);
  if (phase !== world.phase) {
    world.phase = phase;
    const project = world.projects[0];
    if (project && !world.overrides.alexander) {
      const next = PROJECT_PHASE[phase] ?? "development";
      if (project.status !== next) {
        project.status = next;
        project.progress = Math.min(96, project.progress + 8);
        pushEvent(world, now, "project_phase_changed", {
          project_id: project.id,
          name: project.name,
          phase: next,
          status: next,
        });
        log(world, now, "project_phase_changed", `${project.name} moved to ${next}.`);
      }
    }
  }

  const meetingIds: string[] = [];
  for (const person of ROSTER) {
    const beat = beatFor(world, person.id, now);
    const previous = world.applied[person.id];
    if (previous === beat.status) {
      if (beat.status === "meeting") meetingIds.push(person.id);
      continue;
    }
    world.applied[person.id] = beat.status;
    pushEvent(world, now, "employee_status_changed", {
      employee_id: person.id,
      name: person.name,
      status: beat.status,
      current_task: beat.task,
    });
    log(world, now, "employee_status_changed", `${person.name} is now ${beat.status}.`);
    if (beat.status === "assigned") {
      pushEvent(world, now, "task_assigned", {
        employee_id: person.id,
        name: person.name,
        task: beat.task,
      });
      log(world, now, "task_assigned", `${person.name} assigned: ${beat.task}.`);
    }
    if (beat.status === "completed") {
      pushEvent(world, now, "task_completed", { employee_id: person.id, name: person.name, task: beat.task });
      log(world, now, "task_completed", `${person.name} completed ${beat.task}.`);
    }
    if (beat.status === "meeting") meetingIds.push(person.id);
    const task = world.tasks.find((item) => item.assigned_employee === person.name && item.project_id === world.projects[0]?.id);
    if (task) {
      task.status = beat.status === "review" ? "review" : beat.status === "failed" ? "blocked" : beat.status === "completed" ? "done" : "in_progress";
      task.progress = beat.status === "completed" ? 100 : beat.status === "failed" ? task.progress : Math.min(95, task.progress + 4);
    }
  }

  const meetingKey = meetingIds.slice().sort().join(",");
  if (meetingIds.length >= 2 && meetingKey !== world.meetingKey) {
    world.meetingKey = meetingKey;
    pushEvent(world, now, "meeting_started", {
      employee_ids: meetingIds,
      topic: "Floor sync",
      room_id: "meeting",
    });
    log(world, now, "meeting_started", "A floor sync started in the meeting room.");
  }
  if (meetingIds.length < 2) world.meetingKey = "";

  return world.events.slice(before);
}

const PLAN_TITLES = [
  "Product Requirements",
  "Design Planning",
  "Technical Architecture",
  "Development Planning",
  "Testing Planning",
];

export function commandWorld(world: World, command: string, now: number): FounderCommandResult {
  const cleaned = command.trim().replace(/^buat\s+/i, "").trim();
  const name = (cleaned || "New Initiative").replace(/\s+/g, " ");
  const titled = name.replace(/\b\w/g, (letter) => letter.toUpperCase());
  const project: Project = {
    id: uid("proj"),
    name: titled,
    status: "planning",
    progress: 8,
    created_at: stamp(now),
  };
  world.projects.unshift(project);
  const tasks = PLAN_TITLES.map((title) => ({
    title,
    description: "Initial planning task",
    priority: "high",
  }));
  for (const task of tasks) {
    world.tasks.unshift({
      id: uid("task"),
      title: task.title,
      status: "todo",
      priority: "high",
      progress: 0,
      assigned_employee: null,
      project_id: project.id,
    });
  }

  const assignments: Record<string, string> = {
    alexander: `Setting strategy for ${titled}`,
    marcus: `Technical plan for ${titled}`,
    olivia: `Requirements for ${titled}`,
    sophia: `Design planning for ${titled}`,
    david: `Development planning for ${titled}`,
    emma: `Test planning for ${titled}`,
  };

  for (const person of ROSTER) {
    const task = assignments[person.id] ?? titled;
    if (person.id === "alexander") {
      world.overrides[person.id] = {
        status: "working",
        task,
        until: now + 36_000,
      };
    } else {
      world.overrides[person.id] = {
        status: "assigned",
        task,
        until: now + 7_000,
        then: { status: "working", task, until: now + 36_000 },
      };
    }
  }

  tickWorld(world, now);
  pushEvent(world, now, "project_phase_changed", {
    project_id: project.id,
    name: project.name,
    phase: "planning",
    status: "planning",
  });
  log(world, now, "ceo_created_project", `Alexander created project ${titled}.`);

  return {
    project: titled,
    strategy: {
      project_name: titled,
      objective: command.trim() || titled,
      target_user: "Founder-defined target users",
      features: ["Core workflow", "Conversion flow", "Contact/support"],
      departments_required: ["Product", "Design", "Technology", "Quality Assurance"],
      priority: "high",
      risk: "Requirements require Founder validation.",
      timeline: "4 weeks",
    },
    tasks,
    status: "planning",
  };
}

export function eventsSince(world: World, since: number): CompanyEvent[] {
  return world.events.filter((event) => event.seq > since);
}
