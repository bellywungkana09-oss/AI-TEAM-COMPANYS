import { useEffect, useRef, useState } from "react";
import type { CompanyEvent } from "@/types/company";

const TRACKED = new Set([
  "employee_status_changed",
  "task_assigned",
  "task_completed",
  "meeting_started",
  "project_phase_changed",
  "company_status_changed",
]);

export function useCompanyEvents(onEvent: (event: CompanyEvent) => void) {
  const [connected, setConnected] = useState(false);
  const handler = useRef(onEvent);
  handler.current = onEvent;

  useEffect(() => {
    let stopped = false;
    let since = 0;
    const seen = new Set<number>();
    let socket: WebSocket | null = null;
    let retry = 0;

    const take = (event: CompanyEvent) => {
      if (!TRACKED.has(event.type) && event.type !== "company_status_changed") return;
      if (event.seq > 0) {
        if (seen.has(event.seq)) return;
        seen.add(event.seq);
        since = Math.max(since, event.seq);
      }
      if (event.type === "company_status_changed") {
        setConnected(true);
        return;
      }
      handler.current(event);
    };

    const poll = async () => {
      try {
        const response = await fetch(`/api/v1/company/events?since=${since}`, { cache: "no-store" });
        if (!response.ok) return;
        const body = (await response.json()) as { events: CompanyEvent[] };
        setConnected(true);
        for (const event of body.events ?? []) take(event);
      } catch {
        setConnected(false);
      }
    };

    const connect = () => {
      if (stopped) return;
      const protocol = window.location.protocol === "https:" ? "wss" : "ws";
      try {
        socket = new WebSocket(`${protocol}://${window.location.host}/ws/company`);
      } catch {
        return;
      }
      socket.onopen = () => setConnected(true);
      socket.onmessage = (message) => {
        try {
          take(JSON.parse(String(message.data)) as CompanyEvent);
        } catch {
          /* ignore malformed frames */
        }
      };
      socket.onclose = () => {
        if (stopped) return;
        retry = window.setTimeout(connect, 4000);
      };
    };

    void poll();
    const timer = window.setInterval(() => void poll(), 1200);
    connect();
    return () => {
      stopped = true;
      window.clearInterval(timer);
      window.clearTimeout(retry);
      socket?.close();
    };
  }, []);

  return connected;
}
