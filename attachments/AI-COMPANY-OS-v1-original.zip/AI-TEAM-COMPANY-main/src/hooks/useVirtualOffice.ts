import { useCallback, useEffect, useState } from "react";
import type { CompanyEvent, FounderCommandResult } from "@/types/company";
import type { OfficeEmployee, VirtualOfficeState } from "@/types/office";
import { animationFor, poseFor, ROSTER } from "@/lib/company/layout";
import { FOUNDER_ID } from "@/lib/company/world";
import { useCompanyEvents } from "./useCompanyEvents";

function fallbackState(): VirtualOfficeState {
  const employees: OfficeEmployee[] = ROSTER.map((person) => {
    const status = person.id === "emma" ? "review" : person.id === "alexander" ? "idle" : "working";
    const pose = poseFor(person.id, status);
    return {
      id: person.id,
      name: person.name,
      role: person.role,
      department: person.department,
      status,
      current_task: null,
      skills: person.skills,
      room_id: person.room_id,
      position: pose.position,
      facing: pose.facing,
      animation: animationFor(person.name, status, false),
    };
  });
  return {
    office: {
      rooms: [],
    },
    employees,
  };
}

function applyEvent(employees: OfficeEmployee[], event: CompanyEvent): OfficeEmployee[] {
  if (event.type === "meeting_started") {
    const ids = new Set((event.data.employee_ids as string[] | undefined) ?? []);
    return employees.map((employee) => {
      if (!ids.has(employee.id)) return employee;
      const pose = poseFor(employee.id, "meeting");
      return {
        ...employee,
        status: "meeting",
        current_task: String(event.data.topic ?? "Floor sync"),
        position: pose.position,
        facing: pose.facing,
        animation: "meeting",
      };
    });
  }
  const id = String(event.data.employee_id ?? "");
  if (!id) return employees;
  return employees.map((employee) => {
    if (employee.id !== id) return employee;
    let status = employee.status;
    let task = employee.current_task;
    if (event.type === "employee_status_changed") {
      status = (event.data.status as OfficeEmployee["status"]) ?? status;
      if (typeof event.data.current_task === "string") task = event.data.current_task;
    } else if (event.type === "task_assigned") {
      status = "assigned";
      task = String(event.data.task ?? task ?? "Assigned");
    } else if (event.type === "task_completed") {
      status = "completed";
      task = String(event.data.task ?? task ?? "Completed");
    }
    const pose = poseFor(employee.id, status);
    return {
      ...employee,
      status,
      current_task: task,
      position: pose.position,
      facing: pose.facing,
      animation: animationFor(employee.name, status, status === "assigned"),
    };
  });
}

export function useVirtualOffice() {
  const [state, setState] = useState<VirtualOfficeState>(() => fallbackState());
  const [feed, setFeed] = useState<CompanyEvent[]>([]);
  const [commandResult, setCommandResult] = useState<FounderCommandResult | null>(null);
  const [commandError, setCommandError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const response = await fetch("/api/v1/virtual-office/state", { cache: "no-store" });
    if (!response.ok) throw new Error("office state unavailable");
    const body = (await response.json()) as VirtualOfficeState;
    setState(body);
  }, []);

  useEffect(() => {
    let dead = false;
    refresh().catch(() => {
      if (!dead) setState(fallbackState());
    });
    return () => {
      dead = true;
    };
  }, [refresh]);

  const connected = useCompanyEvents((event) => {
    setFeed((current) => [event, ...current].slice(0, 8));
    setState((current) => ({ ...current, employees: applyEvent(current.employees, event) }));
    if (event.type === "project_phase_changed" || event.type === "meeting_started") {
      refresh().catch(() => undefined);
    }
  });

  const sendCommand = useCallback(async (command: string) => {
    setCommandError(null);
    const response = await fetch("/api/v1/founder/command", {
      method: "POST",
      headers: { "content-type": "application/json", "x-founder-id": FOUNDER_ID },
      body: JSON.stringify({ command }),
    });
    if (!response.ok) {
      setCommandError("Alexander could not record that command.");
      return;
    }
    const body = (await response.json()) as FounderCommandResult;
    setCommandResult(body);
    await refresh().catch(() => undefined);
  }, [refresh]);

  return { state, feed, connected, commandResult, commandError, sendCommand, refresh };
}
