import { createHash } from "node:crypto";

const MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

function sendText(socket, text) {
  const payload = Buffer.from(text);
  const length = payload.length;
  let header;
  if (length < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x81;
    header[1] = length;
  } else if (length < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(length), 2);
  }
  if (!socket.destroyed) socket.write(Buffer.concat([header, payload]));
}

function acceptKey(key) {
  return createHash("sha1").update(String(key) + MAGIC).digest("base64");
}

/**
 * Dev-only company socket on /ws/company. Production clients fall back to
 * polling /api/v1/company/events, which carries the same event names.
 */
export function companyWsPlugin() {
  return {
    name: "company-ws",
    configureServer(server) {
      server.httpServer?.on("upgrade", (req, socket) => {
        const path = (req.url ?? "").split("?")[0];
        if (path !== "/ws/company") return;
        const key = req.headers["sec-websocket-key"];
        if (!key) {
          socket.destroy();
          return;
        }
        socket.write(
          "HTTP/1.1 101 Switching Protocols\r\n" +
            "Upgrade: websocket\r\n" +
            "Connection: Upgrade\r\n" +
            `Sec-WebSocket-Accept: ${acceptKey(key)}\r\n\r\n`,
        );
        void server.ssrLoadModule("/src/lib/company/world.server.ts").then((mod) => {
          sendText(socket, JSON.stringify(mod.helloEvent()));
          const off = mod.subscribeCompanyEvents((events) => {
            for (const event of events) sendText(socket, JSON.stringify(event));
          });
          const done = () => off();
          socket.on("close", done);
          socket.on("error", done);
          socket.on("data", () => {
            /* client frames are ignored; the floor is server-push */
          });
        });
      });
    },
  };
}
