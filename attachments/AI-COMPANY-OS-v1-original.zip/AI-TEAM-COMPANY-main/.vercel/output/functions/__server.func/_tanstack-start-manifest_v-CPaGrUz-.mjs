//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CPaGrUz-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/dashboard",
			"/virtual-office",
			"/api/v1/$"
		],
		preloads: ["/assets/index-fmae0Cag.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-fmae0Cag.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cv3aNAfB.js", "/assets/VirtualOffice-CC8PUdUk.js"]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: void 0,
		preloads: ["/assets/dashboard-DWRgGfLS.js", "/assets/office-BRuKcRPV.js"]
	},
	"/virtual-office": {
		filePath: "/workspace/src/routes/virtual-office.tsx",
		children: void 0,
		preloads: ["/assets/virtual-office-Cv3aNAfB.js", "/assets/VirtualOffice-CC8PUdUk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
