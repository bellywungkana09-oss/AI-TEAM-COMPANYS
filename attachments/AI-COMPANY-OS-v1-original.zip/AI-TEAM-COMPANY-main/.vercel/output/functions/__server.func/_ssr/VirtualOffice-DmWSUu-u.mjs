import { i as __toESM } from "../_runtime.mjs";
import { a as CanvasTexture, c as require_jsx_runtime, i as useThree, l as require_react, n as Canvas, o as Vector3, r as useFrame, t as ContactShadows } from "../_libs/@react-three/drei+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ROOMS, c as deskPoint, d as resolveWalls, f as visitPoint, i as FOUNDER_SPAWN, l as officeWalls, m as workYaw, n as FOUNDER_ID, o as ROSTER, p as wallsFor, r as ACCENT, s as animationFor, u as poseFor } from "./router-D7rkxY_z.mjs";
import { n as statusLabel, t as CommandComposer } from "./office-BMAu2D-J.mjs";
import { n as MotionConfig, t as motion } from "../_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/VirtualOffice-DmWSUu-u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var pose = {
	x: FOUNDER_SPAWN.x,
	z: FOUNDER_SPAWN.z,
	yaw: FOUNDER_SPAWN.yaw,
	speed: 0,
	nearCeo: false
};
var listeners = /* @__PURE__ */ new Set();
var notifyQueued = false;
function publishFounder(next) {
	if (Math.abs(next.x - pose.x) < .05 && Math.abs(next.z - pose.z) < .05 && Math.abs(next.yaw - pose.yaw) < .03 && Math.abs(next.speed - pose.speed) < .05 && next.nearCeo === pose.nearCeo) return;
	pose = next;
	if (notifyQueued) return;
	notifyQueued = true;
	requestAnimationFrame(() => {
		notifyQueued = false;
		listeners.forEach((listener) => listener());
	});
}
function getFounderPose() {
	return pose;
}
function useFounderPose() {
	return (0, import_react.useSyncExternalStore)((listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	}, getFounderPose, getFounderPose);
}
var TRACKED = /* @__PURE__ */ new Set([
	"employee_status_changed",
	"task_assigned",
	"task_completed",
	"meeting_started",
	"project_phase_changed",
	"company_status_changed"
]);
function useCompanyEvents(onEvent) {
	const [connected, setConnected] = (0, import_react.useState)(false);
	const handler = (0, import_react.useRef)(onEvent);
	handler.current = onEvent;
	(0, import_react.useEffect)(() => {
		let stopped = false;
		let since = 0;
		const seen = /* @__PURE__ */ new Set();
		let socket = null;
		let retry = 0;
		const take = (event) => {
			if (!TRACKED.has(event.type) && event.type !== "company_status_changed") return;
			if (event.seq > 0) {
				if (seen.has(event.seq)) return;
				seen.add(event.seq);
				since = Math.max(since, event.seq);
			}
			if (event.type === "company_status_changed") {
				setConnected(true);
				return;
			}
			handler.current(event);
		};
		const poll = async () => {
			try {
				const response = await fetch(`/api/v1/company/events?since=${since}`, { cache: "no-store" });
				if (!response.ok) return;
				const body = await response.json();
				setConnected(true);
				for (const event of body.events ?? []) take(event);
			} catch {
				setConnected(false);
			}
		};
		const connect = () => {
			if (stopped) return;
			const protocol = window.location.protocol === "https:" ? "wss" : "ws";
			try {
				socket = new WebSocket(`${protocol}://${window.location.host}/ws/company`);
			} catch {
				return;
			}
			socket.onopen = () => setConnected(true);
			socket.onmessage = (message) => {
				try {
					take(JSON.parse(String(message.data)));
				} catch {}
			};
			socket.onclose = () => {
				if (stopped) return;
				retry = window.setTimeout(connect, 4e3);
			};
		};
		poll();
		const timer = window.setInterval(() => void poll(), 1200);
		connect();
		return () => {
			stopped = true;
			window.clearInterval(timer);
			window.clearTimeout(retry);
			socket?.close();
		};
	}, []);
	return connected;
}
function fallbackState() {
	return {
		office: { rooms: [] },
		employees: ROSTER.map((person) => {
			const status = person.id === "emma" ? "review" : person.id === "alexander" ? "idle" : "working";
			const pose = poseFor(person.id, status);
			return {
				id: person.id,
				name: person.name,
				role: person.role,
				department: person.department,
				status,
				current_task: null,
				skills: person.skills,
				room_id: person.room_id,
				position: pose.position,
				facing: pose.facing,
				animation: animationFor(person.name, status, false)
			};
		})
	};
}
function applyEvent(employees, event) {
	if (event.type === "meeting_started") {
		const ids = new Set(event.data.employee_ids ?? []);
		return employees.map((employee) => {
			if (!ids.has(employee.id)) return employee;
			const pose = poseFor(employee.id, "meeting");
			return {
				...employee,
				status: "meeting",
				current_task: String(event.data.topic ?? "Floor sync"),
				position: pose.position,
				facing: pose.facing,
				animation: "meeting"
			};
		});
	}
	const id = String(event.data.employee_id ?? "");
	if (!id) return employees;
	return employees.map((employee) => {
		if (employee.id !== id) return employee;
		let status = employee.status;
		let task = employee.current_task;
		if (event.type === "employee_status_changed") {
			status = event.data.status ?? status;
			if (typeof event.data.current_task === "string") task = event.data.current_task;
		} else if (event.type === "task_assigned") {
			status = "assigned";
			task = String(event.data.task ?? task ?? "Assigned");
		} else if (event.type === "task_completed") {
			status = "completed";
			task = String(event.data.task ?? task ?? "Completed");
		}
		const pose = poseFor(employee.id, status);
		return {
			...employee,
			status,
			current_task: task,
			position: pose.position,
			facing: pose.facing,
			animation: animationFor(employee.name, status, status === "assigned")
		};
	});
}
function useVirtualOffice() {
	const [state, setState] = (0, import_react.useState)(() => fallbackState());
	const [feed, setFeed] = (0, import_react.useState)([]);
	const [commandResult, setCommandResult] = (0, import_react.useState)(null);
	const [commandError, setCommandError] = (0, import_react.useState)(null);
	const refresh = (0, import_react.useCallback)(async () => {
		const response = await fetch("/api/v1/virtual-office/state", { cache: "no-store" });
		if (!response.ok) throw new Error("office state unavailable");
		const body = await response.json();
		setState(body);
	}, []);
	(0, import_react.useEffect)(() => {
		let dead = false;
		refresh().catch(() => {
			if (!dead) setState(fallbackState());
		});
		return () => {
			dead = true;
		};
	}, [refresh]);
	return {
		state,
		feed,
		connected: useCompanyEvents((event) => {
			setFeed((current) => [event, ...current].slice(0, 8));
			setState((current) => ({
				...current,
				employees: applyEvent(current.employees, event)
			}));
			if (event.type === "project_phase_changed" || event.type === "meeting_started") refresh().catch(() => void 0);
		}),
		commandResult,
		commandError,
		sendCommand: (0, import_react.useCallback)(async (command) => {
			setCommandError(null);
			const response = await fetch("/api/v1/founder/command", {
				method: "POST",
				headers: {
					"content-type": "application/json",
					"x-founder-id": FOUNDER_ID
				},
				body: JSON.stringify({ command })
			});
			if (!response.ok) {
				setCommandError("Alexander could not record that command.");
				return;
			}
			const body = await response.json();
			setCommandResult(body);
			await refresh().catch(() => void 0);
		}, [refresh]),
		refresh
	};
}
var WALLS = officeWalls();
function clamp(value, min, max) {
	return Math.max(min, Math.min(max, value));
}
function wrapPi(angle) {
	return Math.atan2(Math.sin(angle), Math.cos(angle));
}
function axesFromInput(keys, touch) {
	let steer = 0;
	let throttle = 0;
	if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
	if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;
	if (keys.has("KeyW") || keys.has("ArrowUp")) throttle += 1;
	if (keys.has("KeyS") || keys.has("ArrowDown")) throttle -= 1;
	if (steer === 0 && throttle === 0) {
		steer = touch.steer;
		throttle = touch.throttle;
	}
	return {
		steer: clamp(steer, -1, 1),
		throttle: clamp(throttle, -1, 1)
	};
}
/**
* On-foot founder. yaw 0 faces world −Z.
* A / left increases yaw (nose turns left under the chase camera).
* D / right decreases yaw.
*/
function stepWalker(walker, keys, touch, autopilot, dt, walls = WALLS) {
	const delta = Math.min(Math.max(dt, 0), .1);
	let { steer, throttle } = axesFromInput(keys, touch);
	let dropAutopilot = false;
	if (steer === 0 && throttle === 0 && autopilot && keys.size === 0) {
		const dx = autopilot.x - walker.x;
		const dz = autopilot.z - walker.z;
		if (Math.hypot(dx, dz) < .55) dropAutopilot = true;
		else {
			const diff = wrapPi(Math.atan2(-dx, -dz) - walker.yaw);
			steer = clamp(diff * 2.4, -1, 1);
			throttle = Math.abs(diff) < .9 ? 1 : .4;
		}
	}
	const turnRate = 2.35;
	let speed = walker.speed + throttle * 9 * delta;
	if (throttle === 0) {
		const drag = 8 * delta;
		if (Math.abs(speed) <= drag) speed = 0;
		else speed -= Math.sign(speed) * drag;
	}
	speed = clamp(speed, -2.4, 4.4);
	const moving = Math.abs(speed) > .08 || Math.abs(throttle) > 0;
	const speedFactor = Math.min(1, Math.abs(speed) / 1.15);
	const reverse = speed >= 0 ? 1 : -1;
	const yaw = walker.yaw + steer * turnRate * (moving ? Math.max(speedFactor, Math.abs(throttle) > 0 ? .72 : 0) : 0) * reverse * delta;
	const fx = -Math.sin(yaw);
	const fz = -Math.cos(yaw);
	const resolved = resolveWalls(walker.x + fx * speed * delta, walker.z + fz * speed * delta, .34, walls);
	return {
		x: resolved.x,
		z: resolved.z,
		yaw,
		speed: dropAutopilot ? 0 : speed
	};
}
function autopilotCleared(walker, autopilot) {
	if (!autopilot) return false;
	return Math.hypot(autopilot.x - walker.x, autopilot.z - walker.z) < .55 && Math.abs(walker.speed) < .2;
}
var desired = new Vector3();
var look = new Vector3();
function CameraController({ control, alexander }) {
	const { camera, gl } = useThree();
	const body = (0, import_react.useRef)(null);
	const walker = (0, import_react.useRef)({
		x: FOUNDER_SPAWN.x,
		z: FOUNDER_SPAWN.z,
		yaw: FOUNDER_SPAWN.yaw,
		speed: 0
	});
	const keys = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const injected = (0, import_react.useRef)(null);
	const dragging = (0, import_react.useRef)(false);
	const lastX = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const down = (event) => {
			if (event.repeat) return;
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
			if ([
				"KeyW",
				"KeyA",
				"KeyS",
				"KeyD",
				"ArrowUp",
				"ArrowDown",
				"ArrowLeft",
				"ArrowRight"
			].includes(event.code)) event.preventDefault();
			injected.current = null;
			keys.current.add(event.code);
		};
		const up = (event) => keys.current.delete(event.code);
		const blur = () => keys.current.clear();
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", blur);
		const probe = {
			getYaw: () => walker.current.yaw,
			getSpeed: () => walker.current.speed,
			setKeys: (codes) => {
				injected.current = new Set(codes);
			},
			setSteer: (value) => {
				control.touch.steer = value;
			}
		};
		window.__controlsTest = probe;
		return () => {
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", blur);
			if (window.__controlsTest === probe) delete window.__controlsTest;
		};
	}, [control]);
	(0, import_react.useEffect)(() => {
		const canvas = gl.domElement;
		const pointerDown = (event) => {
			if (!control.playing) return;
			dragging.current = true;
			lastX.current = event.clientX;
		};
		const pointerMove = (event) => {
			if (!dragging.current) return;
			const dx = event.clientX - lastX.current;
			lastX.current = event.clientX;
			walker.current.yaw -= dx * .005;
		};
		const pointerUp = () => {
			dragging.current = false;
		};
		canvas.addEventListener("pointerdown", pointerDown);
		window.addEventListener("pointermove", pointerMove);
		window.addEventListener("pointerup", pointerUp);
		return () => {
			canvas.removeEventListener("pointerdown", pointerDown);
			window.removeEventListener("pointermove", pointerMove);
			window.removeEventListener("pointerup", pointerUp);
		};
	}, [gl, control]);
	useFrame((_, delta) => {
		const activeKeys = injected.current ?? keys.current;
		if (control.playing || injected.current != null) {
			const next = stepWalker(walker.current, activeKeys, control.touch, control.autopilot, delta);
			walker.current = next;
			if (control.autopilot && (activeKeys.size > 0 || autopilotCleared(next, control.autopilot))) {
				if (activeKeys.size > 0 || autopilotCleared(next, control.autopilot)) control.autopilot = null;
			}
		}
		const { x, z, yaw, speed } = walker.current;
		body.current?.position.set(x, 0, z);
		if (body.current) body.current.rotation.y = Math.PI + yaw;
		const fx = -Math.sin(yaw);
		const fz = -Math.cos(yaw);
		desired.set(x - fx * 4.8, 2.25, z - fz * 4.8);
		const blend = 1 - Math.exp(-5.5 * Math.min(delta, .1));
		camera.position.lerp(desired, blend);
		look.set(x, 1.15, z);
		camera.lookAt(look);
		publishFounder({
			x,
			z,
			yaw,
			speed,
			nearCeo: alexander ? Math.hypot(alexander.x - x, alexander.z - z) < 2.35 : false
		});
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref: body,
		position: [
			FOUNDER_SPAWN.x,
			0,
			FOUNDER_SPAWN.z
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.95,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
					.22,
					.7,
					6,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#1c2430",
					metalness: .35,
					roughness: .4
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.45,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.16,
					18,
					14
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#d6b36a",
					emissive: "#d6b36a",
					emissiveIntensity: .25
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.04,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
					.34,
					.42,
					24
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
					color: "#d6b36a",
					transparent: true,
					opacity: .8
				})]
			})
		]
	});
}
function labelTexture(name, role, status, alert) {
	const canvas = document.createElement("canvas");
	canvas.width = 512;
	canvas.height = 192;
	const ctx = canvas.getContext("2d");
	if (!ctx) return new CanvasTexture(canvas);
	ctx.clearRect(0, 0, 512, 192);
	ctx.fillStyle = "rgba(7, 9, 14, 0.78)";
	ctx.strokeStyle = alert ? "#e15b64" : "#2a3848";
	ctx.lineWidth = 6;
	roundRect(ctx, 8, 16, 496, 160, 28);
	ctx.fill();
	ctx.stroke();
	ctx.textAlign = "center";
	ctx.fillStyle = "#e7eef6";
	ctx.font = "600 54px Outfit, sans-serif";
	ctx.fillText(name, 256, 78);
	ctx.fillStyle = "#8d9aab";
	ctx.font = "500 32px Outfit, sans-serif";
	ctx.fillText(role.replace(" AI", ""), 256, 122);
	ctx.fillStyle = alert ? "#e15b64" : "#3ec5ff";
	ctx.font = "600 26px Outfit, sans-serif";
	ctx.fillText(statusLabel(status), 256, 158);
	const texture = new CanvasTexture(canvas);
	texture.needsUpdate = true;
	return texture;
}
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.arcTo(x + w, y, x + w, y + h, r);
	ctx.arcTo(x + w, y + h, x, y + h, r);
	ctx.arcTo(x, y + h, x, y, r);
	ctx.arcTo(x, y, x + w, y, r);
	ctx.closePath();
}
function EmployeeStatusBubble({ name, role, status }) {
	const texture = (0, import_react.useMemo)(() => labelTexture(name, role, status, status === "failed"), [
		name,
		role,
		status
	]);
	(0, import_react.useEffect)(() => () => texture.dispose(), [texture]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
		position: [
			0,
			1.95,
			0
		],
		scale: [
			1.35,
			.5,
			1
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
			map: texture,
			transparent: true,
			depthWrite: false
		})
	});
}
function EmployeeAvatar({ name, role, status, accent, animation, position, facing, selected, onSelect }) {
	const root = (0, import_react.useRef)(null);
	const leftArm = (0, import_react.useRef)(null);
	const rightArm = (0, import_react.useRef)(null);
	const leftLeg = (0, import_react.useRef)(null);
	const rightLeg = (0, import_react.useRef)(null);
	const head = (0, import_react.useRef)(null);
	const spot = (0, import_react.useRef)({
		x: position.x,
		z: position.z,
		facing
	});
	useFrame((state, delta) => {
		const rig = root.current;
		if (!rig) return;
		const dt = Math.min(delta, .1);
		const current = spot.current;
		current.x += (position.x - current.x) * Math.min(1, dt * 2.4);
		current.z += (position.z - current.z) * Math.min(1, dt * 2.4);
		let turn = Math.atan2(Math.sin(facing - current.facing), Math.cos(facing - current.facing));
		current.facing += turn * Math.min(1, dt * 4);
		const anim = Math.hypot(position.x - current.x, position.z - current.z) > .22 ? "walk" : animation;
		const t = state.clock.elapsedTime;
		const seated = anim === "working" || anim === "review";
		rig.position.set(current.x, seated ? -.22 : Math.sin(t * 1.6) * .015, current.z);
		rig.rotation.y = Math.PI + current.facing;
		const armL = leftArm.current;
		const armR = rightArm.current;
		const legL = leftLeg.current;
		const legR = rightLeg.current;
		const skull = head.current;
		if (!armL || !armR || !legL || !legR || !skull) return;
		armL.rotation.set(.12, 0, .08);
		armR.rotation.set(.12, 0, -.08);
		legL.rotation.set(0, 0, 0);
		legR.rotation.set(0, 0, 0);
		skull.rotation.set(0, Math.sin(t * .6) * .12, 0);
		if (anim === "walk") {
			const step = Math.sin(t * 8);
			legL.rotation.x = step * .55;
			legR.rotation.x = -step * .55;
			armL.rotation.x = -step * .45;
			armR.rotation.x = step * .45;
		} else if (anim === "working") {
			armL.rotation.x = -.95 + Math.sin(t * 11) * .22;
			armR.rotation.x = -.95 + Math.sin(t * 11 + 1.2) * .22;
			skull.rotation.x = .28;
		} else if (anim === "review") {
			armL.rotation.x = -.7;
			armR.rotation.x = -.75;
			skull.rotation.x = .42;
		} else if (anim === "meeting") {
			armR.rotation.x = -.7 + Math.sin(t * 2.2) * .35;
			armR.rotation.z = -.25;
			skull.rotation.y = Math.sin(t * 1.1) * .3;
		} else if (anim === "thinking") {
			armR.rotation.x = -1.35;
			armR.rotation.z = -.45;
			skull.rotation.x = -.12 + Math.sin(t * .8) * .06;
		} else if (anim === "failed") {
			rig.position.x += Math.sin(t * 16) * .012;
			skull.rotation.x = .15;
		} else if (anim === "completed") skull.rotation.x = Math.max(0, Math.sin(t * 1.4)) * .28;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref: root,
		onClick: (event) => {
			event.stopPropagation();
			onSelect();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				rotation: [
					-Math.PI / 2,
					0,
					0
				],
				position: [
					0,
					.03,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
					.28,
					selected ? .4 : .34,
					28
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
					color: status === "failed" ? "#e15b64" : accent,
					transparent: true,
					opacity: selected ? .95 : .55
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				ref: leftLeg,
				position: [
					-.1,
					.74,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.28,
						0
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
						.065,
						.34,
						4,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: "#1b2028",
						roughness: .7
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				ref: rightLeg,
				position: [
					.1,
					.74,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.28,
						0
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
						.065,
						.34,
						4,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: "#1b2028",
						roughness: .7
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.02,
					0
				],
				castShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.4,
					.46,
					.22
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#2a3140",
					metalness: .28,
					roughness: .46
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.16,
					.1
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.14,
					.05,
					.02
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: accent,
					emissive: accent,
					emissiveIntensity: .55
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				ref: leftArm,
				position: [
					-.26,
					1.2,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.2,
						0
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
						.045,
						.26,
						4,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: "#343c4c",
						roughness: .5
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				ref: rightArm,
				position: [
					.26,
					1.2,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.2,
						0
					],
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
						.045,
						.26,
						4,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: "#343c4c",
						roughness: .5
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				ref: head,
				position: [
					0,
					1.46,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					castShadow: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						.125,
						22,
						16
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: "#e4d0be",
						roughness: .62
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						.05,
						-.01
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						.128,
						16,
						12,
						0,
						Math.PI * 2,
						0,
						Math.PI * .48
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: "#17191e",
						roughness: .55
					})]
				})]
			}),
			(animation === "review" || status === "review") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.02,
					1.02,
					.2
				],
				rotation: [
					-.55,
					0,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.2,
					.13,
					.018
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#0e141b",
					emissive: "#3ec5ff",
					emissiveIntensity: .45
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeStatusBubble, {
				name,
				role,
				status
			})
		]
	});
}
function Desk({ room, active }) {
	const screen = (0, import_react.useRef)(null);
	const spot = deskPoint(room);
	const yaw = workYaw(room);
	const accent = room.accent === "gold" ? ACCENT.gold : ACCENT.blue;
	useFrame((state) => {
		const material = screen.current?.material;
		if (!material || Array.isArray(material) || !("emissiveIntensity" in material)) return;
		material.emissiveIntensity = active ? .7 + Math.sin(state.clock.elapsedTime * 3) * .25 : .18;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			spot.x,
			0,
			spot.z
		],
		rotation: [
			0,
			yaw,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.74,
					0
				],
				castShadow: true,
				receiveShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					1.35,
					.06,
					.62
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#1a212b",
					metalness: .45,
					roughness: .35
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.55,
					.38,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.06,
					.7,
					.5
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#12171e" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.55,
					.38,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.06,
					.7,
					.5
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#12171e" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.78,
					.16
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.42,
					.02,
					.16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#0c1016" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.08,
					-.18
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.72,
					.46,
					.04
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#0a0e13",
					metalness: .6,
					roughness: .25
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				ref: screen,
				position: [
					0,
					1.08,
					-.15
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [.62, .36] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: accent,
					emissive: accent,
					emissiveIntensity: .4,
					toneMapped: false
				})]
			})
		]
	});
}
function Wall({ box, accent }) {
	const sx = Math.max(.08, box.maxX - box.minX);
	const sz = Math.max(.08, box.maxZ - box.minZ);
	const cx = (box.minX + box.maxX) / 2;
	const cz = (box.minZ + box.maxZ) / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			cx,
			0,
			cz
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.38,
					0
				],
				castShadow: true,
				receiveShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					sx,
					.76,
					sz
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#141a22",
					metalness: .22,
					roughness: .62
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.72,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					sx,
					1.86,
					sz
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#c5deea",
					transparent: true,
					opacity: .14,
					roughness: .04,
					metalness: .2,
					depthWrite: false
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					2.68,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					sx,
					.045,
					sz
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: accent,
					emissive: accent,
					emissiveIntensity: .85,
					toneMapped: false
				})]
			})
		]
	});
}
function OfficeRoom({ room, deskActive }) {
	const accent = room.accent === "gold" ? ACCENT.gold : ACCENT.blue;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				room.x,
				.02,
				room.z
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [room.w - .2, room.d - .2] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: room.accent === "gold" ? "#16140f" : "#10161c",
				roughness: .85
			})]
		}),
		wallsFor(room).map((box, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wall, {
			box,
			accent
		}, `${room.id}-${index}`)),
		room.id !== "meeting" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {
			room,
			active: deskActive
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomLabel, {
			name: room.name,
			gold: room.accent === "gold",
			position: [
				room.x,
				2.45,
				room.z
			]
		})
	] });
}
function RoomLabel({ name, gold, position }) {
	const texture = (0, import_react.useMemo)(() => {
		const canvas = document.createElement("canvas");
		canvas.width = 512;
		canvas.height = 96;
		const ctx = canvas.getContext("2d");
		if (ctx) {
			ctx.clearRect(0, 0, 512, 96);
			ctx.fillStyle = "rgba(7, 9, 14, 0.55)";
			ctx.fillRect(24, 16, 464, 64);
			ctx.fillStyle = gold ? "#d6b36a" : "#e7eef6";
			ctx.font = "600 34px Outfit, sans-serif";
			ctx.textAlign = "center";
			ctx.fillText(name.toUpperCase(), 256, 58);
		}
		const map = new CanvasTexture(canvas);
		map.needsUpdate = true;
		return map;
	}, [gold, name]);
	(0, import_react.useEffect)(() => () => texture.dispose(), [texture]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
		position,
		scale: [
			2.4,
			.45,
			1
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
			map: texture,
			transparent: true,
			depthWrite: false
		})
	});
}
function StatusWall({ employees }) {
	const mesh = (0, import_react.useRef)(null);
	const texture = (0, import_react.useMemo)(() => {
		const canvas = document.createElement("canvas");
		canvas.width = 640;
		canvas.height = 360;
		const map = new CanvasTexture(canvas);
		map.anisotropy = 4;
		return {
			canvas,
			map
		};
	}, []);
	useFrame(() => {
		const ctx = texture.canvas.getContext("2d");
		if (!ctx) return;
		ctx.fillStyle = "#0c1218";
		ctx.fillRect(0, 0, 640, 360);
		ctx.strokeStyle = "#3ec5ff";
		ctx.globalAlpha = .85;
		ctx.lineWidth = 3;
		ctx.strokeRect(16, 16, 608, 328);
		ctx.globalAlpha = 1;
		ctx.fillStyle = "#d6b36a";
		ctx.font = "600 28px Outfit, sans-serif";
		ctx.fillText("COMPANY FLOOR", 40, 62);
		ctx.font = "500 22px Outfit, sans-serif";
		employees.forEach((employee, index) => {
			const y = 112 + index * 38;
			ctx.fillStyle = employee.status === "failed" ? "#e15b64" : "#3ec5ff";
			ctx.fillRect(40, y - 14, 10, 10);
			ctx.fillStyle = "#e7eef6";
			ctx.fillText(employee.name, 64, y);
			ctx.fillStyle = "#8d9aab";
			ctx.fillText(employee.status, 280, y);
		});
		texture.map.needsUpdate = true;
		const material = mesh.current?.material;
		if (material && !Array.isArray(material) && "emissiveIntensity" in material) material.emissiveIntensity = .45;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		ref: mesh,
		position: [
			0,
			1.65,
			3.4
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [3.5, 1.96] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			map: texture.map,
			emissive: "#081018",
			emissiveIntensity: .35,
			toneMapped: false
		})]
	});
}
function MeetingTable() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			0,
			0,
			-2.1
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.74,
					0
				],
				castShadow: true,
				receiveShadow: true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					3.3,
					.08,
					1.35
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#1a1814",
					metalness: .5,
					roughness: .32
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.785,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					2.9,
					.012,
					.035
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#d6b36a",
					emissive: "#d6b36a",
					emissiveIntensity: .45,
					toneMapped: false
				})]
			}),
			[-1.35, 1.35].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					x,
					.38,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.08,
					.7,
					1.05
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#12171e" })]
			}, x))
		]
	});
}
function OfficeScene({ employees, selectedId, onSelect, control }) {
	const alexander = employees.find((employee) => employee.id === "alexander");
	const accents = Object.fromEntries(ROSTER.map((person) => [person.id, person.accent]));
	const busyRooms = new Set(employees.filter((employee) => [
		"working",
		"review",
		"failed",
		"assigned"
	].includes(employee.status)).map((employee) => employee.room_id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#07090e"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
			attach: "fog",
			args: [
				"#07090e",
				18,
				48
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .38 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				10,
				18,
				8
			],
			intensity: 1.2,
			castShadow: true,
			"shadow-mapSize-width": 2048,
			"shadow-mapSize-height": 2048,
			"shadow-camera-far": 64,
			"shadow-camera-left": -26,
			"shadow-camera-right": 26,
			"shadow-camera-top": 26,
			"shadow-camera-bottom": -26,
			"shadow-bias": -4e-4
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				0,
				3.2,
				-16
			],
			intensity: 6,
			color: "#d6b36a",
			distance: 12
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				0,
				3.1,
				-2
			],
			intensity: 5,
			color: "#3ec5ff",
			distance: 14
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				13,
				2.8,
				8
			],
			intensity: 4,
			color: "#3ec5ff",
			distance: 10
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				-13,
				2.8,
				8
			],
			intensity: 3.2,
			color: "#d6b36a",
			distance: 10
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				0,
				0
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [46, 48] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#0c1016",
				roughness: .92,
				metalness: .08
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("gridHelper", {
			args: [
				40,
				40,
				"#1d3c52",
				"#16202b"
			],
			position: [
				0,
				.012,
				0
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactShadows, {
			position: [
				0,
				.03,
				0
			],
			opacity: .4,
			scale: 36,
			blur: 2.4,
			far: 8,
			color: "#020304"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.02,
				2.2
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
				5.4,
				5.48,
				72
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: "#d6b36a",
				transparent: true,
				opacity: .4
			})]
		}),
		ROOMS.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfficeRoom, {
			room,
			deskActive: room.id === "meeting" ? employees.some((employee) => employee.status === "meeting") : busyRooms.has(room.id)
		}, room.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeetingTable, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusWall, { employees }),
		employees.map((employee) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeAvatar, {
			name: employee.name,
			role: employee.role,
			status: employee.status,
			accent: accents[employee.id] ?? "#3ec5ff",
			animation: employee.animation,
			position: employee.position,
			facing: employee.facing,
			selected: selectedId === employee.id,
			onSelect: () => onSelect(employee.id)
		}, employee.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraController, {
			control,
			alexander: alexander ? {
				x: alexander.position.x,
				z: alexander.position.z
			} : null
		})
	] });
}
function InteractionPanel({ employee, alexander, nearCeo, onClose, onCommand }) {
	const showCeo = nearCeo || employee?.id === "alexander";
	if (!employee && !showCeo) return null;
	const ceo = employee?.id === "alexander" ? employee : alexander;
	const person = employee;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.aside, {
		className: "office-panel",
		initial: {
			opacity: 0,
			y: 10
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .25,
			ease: [
				.22,
				1,
				.36,
				1
			]
		},
		children: [showCeo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "office-panel-block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "office-kicker",
					children: "Executive"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "CEO Alexander" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "office-status-line",
					children: ["Status ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: statusLabel(ceo?.status ?? "idle") })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "office-primary",
					onClick: onCommand,
					children: "Send Command"
				})
			]
		}), person && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "office-panel-block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "office-panel-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "office-kicker",
						children: person.department
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "office-text",
						onClick: onClose,
						children: "Close"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: person.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "office-facts",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: person.role })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Department" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: person.department })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: statusLabel(person.status) })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Current task" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: person.current_task ?? "None" })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "office-kicker",
					children: "Skills"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "office-skills",
					children: person.skills.map((skill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: skill }, skill))
				})
			]
		})]
	});
}
function VirtualOffice() {
	const office = useVirtualOffice();
	const control = (0, import_react.useRef)({
		playing: false,
		touch: {
			steer: 0,
			throttle: 0
		},
		autopilot: null
	}).current;
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [commandOpen, setCommandOpen] = (0, import_react.useState)(false);
	const [directoryOpen, setDirectoryOpen] = (0, import_react.useState)(false);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const employees = office.state.employees;
	const selected = employees.find((employee) => employee.id === selectedId) ?? null;
	const alexander = employees.find((employee) => employee.id === "alexander") ?? null;
	(0, import_react.useEffect)(() => setMounted(true), []);
	function enter() {
		control.playing = true;
		setPlaying(true);
	}
	function approach(roomId) {
		const room = ROOMS.find((item) => item.id === roomId);
		if (!room) return;
		control.autopilot = visitPoint(room);
		control.playing = true;
		setPlaying(true);
		setDirectoryOpen(false);
	}
	function approachPerson(id) {
		const person = employees.find((employee) => employee.id === id);
		if (!person) return;
		control.autopilot = {
			x: person.position.x,
			z: person.position.z + 1.55
		};
		control.playing = true;
		setPlaying(true);
		setSelectedId(id);
		setDirectoryOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotionConfig, {
		reducedMotion: "user",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "office-root",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "office-canvas",
					children: mounted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
						shadows: true,
						dpr: [1, 1.6],
						camera: {
							position: [
								0,
								2.4,
								12
							],
							fov: 56,
							near: .1,
							far: 80
						},
						gl: {
							antialias: true,
							powerPreference: "high-performance"
						},
						onPointerMissed: () => setSelectedId(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfficeScene, {
							employees,
							selectedId,
							onSelect: setSelectedId,
							control
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "office-top",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "office-kicker",
						children: "AI Company OS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Virtual floor" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "office-top-actions",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: office.connected ? "office-live is-on" : "office-live",
							children: office.connected ? "Live" : "Linking"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dashboard",
							className: "office-ghost",
							children: "Command Center"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "office-feed",
					"aria-live": "polite",
					children: office.feed.slice(0, 3).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: eventLabel(event.type, event.data) }, event.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloorMap, { employees }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloorDossier, {
					employee: selected,
					alexander,
					onClose: () => setSelectedId(null),
					onCommand: () => setCommandOpen(true)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "office-stick",
					"aria-hidden": !playing,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Joystick, { onChange: (axes) => {
						control.touch = axes;
					} }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Move" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "office-help",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "W forward · S back · A turn left · D turn right" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "office-ghost",
						onClick: () => setDirectoryOpen((open) => !open),
						children: "Rooms"
					})]
				}),
				directoryOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "office-directory",
					children: [employees.map((employee) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => approachPerson(employee.id),
						children: employee.name
					}, employee.id)), ROOMS.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => approach(room.id),
						children: room.name
					}, room.id))]
				}),
				commandOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "office-modal-back",
					role: "presentation",
					onClick: () => setCommandOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						className: "office-modal",
						role: "dialog",
						"aria-labelledby": "command-title",
						initial: {
							opacity: 0,
							y: 12
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .25,
							ease: [
								.22,
								1,
								.36,
								1
							]
						},
						onClick: (event) => event.stopPropagation(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "office-kicker",
								children: "Founder command"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "command-title",
								children: "Instruct Alexander"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "office-note",
								children: "Same command desk as the Command Center. Plans and assignments only — nothing is deployed."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandComposer, { onSubmit: async (command) => {
								await office.sendCommand(command);
							} }),
							office.commandError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "office-alert",
								children: office.commandError
							}),
							office.commandResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "office-result",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"Project ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: office.commandResult.project }),
									" · ",
									office.commandResult.status
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: office.commandResult.strategy.objective })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "office-ghost",
								onClick: () => setCommandOpen(false),
								children: "Close"
							})
						]
					})
				}),
				!playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "office-gate",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "office-kicker",
							children: "Headquarters"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "The company is already at work." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Walk the floor. Alexander holds the CEO room, Marcus is in Technology, Sophia is designing, David is at the development desk, and Emma is in review." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "office-primary",
							onClick: enter,
							children: "Start"
						})
					] })
				})
			]
		})
	});
}
function FloorMap({ employees }) {
	const pose = useFounderPose();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "office-map",
		viewBox: "-22 -22 44 44",
		role: "img",
		"aria-label": "Floor map",
		children: [
			ROOMS.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: room.x - room.w / 2,
				y: room.z - room.d / 2,
				width: room.w,
				height: room.d,
				className: room.accent === "gold" ? "map-gold" : "map-blue"
			}, room.id)),
			employees.map((employee) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: employee.position.x,
				cy: employee.position.z,
				r: .55,
				className: "map-person"
			}, employee.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: pose.x,
				cy: pose.z,
				r: .7,
				className: "map-founder"
			})
		]
	});
}
function FloorDossier({ employee, alexander, onClose, onCommand }) {
	const pose = useFounderPose();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InteractionPanel, {
		employee,
		alexander,
		nearCeo: pose.nearCeo,
		onClose,
		onCommand
	});
}
function eventLabel(type, data) {
	const name = typeof data.name === "string" ? data.name : "Company";
	if (type === "employee_status_changed") return `${name} · ${String(data.status ?? "updated")}`;
	if (type === "task_assigned") return `${name} assigned`;
	if (type === "task_completed") return `${name} completed a task`;
	if (type === "meeting_started") return "Meeting started";
	if (type === "project_phase_changed") return `${String(data.name ?? "Project")} · ${String(data.phase ?? data.status ?? "")}`;
	return type;
}
function Joystick({ onChange }) {
	const pad = (0, import_react.useRef)(null);
	const pointer = (0, import_react.useRef)(null);
	function update(clientX, clientY) {
		const el = pad.current;
		if (!el) return;
		const rect = el.getBoundingClientRect();
		const dx = (clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
		const dy = (clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
		const dead = (value) => Math.abs(value) < .18 ? 0 : Math.max(-1, Math.min(1, value));
		onChange({
			steer: dead(-dx),
			throttle: dead(-dy)
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: pad,
		className: "office-pad",
		onPointerDown: (event) => {
			pointer.current = event.pointerId;
			event.currentTarget.setPointerCapture(event.pointerId);
			update(event.clientX, event.clientY);
		},
		onPointerMove: (event) => {
			if (pointer.current !== event.pointerId) return;
			update(event.clientX, event.clientY);
		},
		onPointerUp: (event) => {
			if (pointer.current !== event.pointerId) return;
			pointer.current = null;
			onChange({
				steer: 0,
				throttle: 0
			});
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
	});
}
//#endregion
export { VirtualOffice as t };
