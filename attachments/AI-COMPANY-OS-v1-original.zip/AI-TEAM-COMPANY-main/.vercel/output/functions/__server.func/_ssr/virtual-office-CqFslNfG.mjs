import { t as VirtualOffice } from "./VirtualOffice-DmWSUu-u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/virtual-office-CqFslNfG.js
var SplitComponent = VirtualOffice;
//#endregion
export { SplitComponent as component };
